﻿/*
BEGIN
Tulio Benedito
12/04/2022
*/
/* Create AspNetUsers Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetUsers](
  [Id] [nvarchar](128) NOT NULL,
  [Hometown] [nvarchar](max) NULL,
  [Email] [nvarchar](256) NULL,
  [EmailConfirmed] [bit] NOT NULL,
  [PasswordHash] [nvarchar](max) NULL,
  [SecurityStamp] [nvarchar](max) NULL,
  [PhoneNumber] [nvarchar](max) NULL,
  [PhoneNumberConfirmed] [bit] NOT NULL,
  [TwoFactorEnabled] [bit] NOT NULL,
  [LockoutEndDateUtc] [datetime] NULL,
  [LockoutEnabled] [bit] NOT NULL,
  [AccessFailedCount] [int] NOT NULL,
  [UserName] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUsers] PRIMARY KEY CLUSTERED 
(
  [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/* Create AspNetUsersExt Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetUsersExt](
  [UserId] [nvarchar](128) NOT NULL,
  [SecurityQuestion] [nvarchar](256) NULL,
  [SecurityAnswer] [nvarchar](128) NULL,
  [SecurityAnswerSalt] [nvarchar](128) NULL,
 CONSTRAINT [PK_AspNetUsersExt] PRIMARY KEY CLUSTERED 
(
  [UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 

GO

ALTER TABLE [dbo].[AspNetUsersExt]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserExt_AspNetUsers] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUsersExt] CHECK CONSTRAINT [FK_AspNetUserExt_AspNetUsers]
GO

/* Create AspNetRoles Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetRoles](
  [Id] [nvarchar](128) NOT NULL,
  [Name] [nvarchar](256) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetRoles] PRIMARY KEY CLUSTERED 
(
  [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

/* Create AspNetUserLogins Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetUserLogins](
  [LoginProvider] [nvarchar](128) NOT NULL,
  [ProviderKey] [nvarchar](128) NOT NULL,
  [UserId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
  [LoginProvider] ASC,
  [ProviderKey] ASC,
  [UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_dbo.AspNetUserLogins_dbo.AspNetUsers_UserId]
GO

/* Create AspNetUserClaims Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetUserClaims](
  [Id] [int] IDENTITY(1,1) NOT NULL,
  [UserId] [nvarchar](128) NOT NULL,
  [ClaimType] [nvarchar](max) NULL,
  [ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_dbo.AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
  [Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_dbo.AspNetUserClaims_dbo.AspNetUsers_UserId]
GO

/* Create AspNetUserRoles Table */
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AspNetUserRoles](
  [UserId] [nvarchar](128) NOT NULL,
  [RoleId] [nvarchar](128) NOT NULL,
 CONSTRAINT [PK_dbo.AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
  [UserId] ASC,
  [RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)

GO

ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetRoles_RoleId]
GO

ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_dbo.AspNetUserRoles_dbo.AspNetUsers_UserId]
GO

/*Migrate Membership Database Users*/
BEGIN TRANSACTION MigrateUsers

  /* Migrate users */
  INSERT INTO AspNetUsers (Id,UserName,PasswordHash,SecurityStamp,EmailConfirmed,
  PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,
  Email)
  SELECT TOP 10 aspnet_Users.UserId, aspnet_Membership.Email,
  (aspnet_Membership.Password+'|'+CAST(aspnet_Membership.PasswordFormat as varchar)+'|'+aspnet_Membership.PasswordSalt),
  NewID(), 1, NULL, 0, 1, CASE WHEN aspnet_Membership.IsLockedOut = 1 THEN DATEADD(YEAR, 1000, SYSUTCDATETIME()) ELSE NULL END, 1, 0,
  aspnet_Membership.Email
  FROM aspnet_Users
  LEFT OUTER JOIN aspnet_Membership ON aspnet_Membership.ApplicationId = aspnet_Users.ApplicationId 
  AND aspnet_Users.UserId = aspnet_Membership.UserId
  LEFT OUTER JOIN AspNetUsers ON aspnet_Membership.UserId = AspNetUsers.Id
  WHERE AspNetUsers.Id IS NULL

  /* Migrate user question/answer */
  INSERT INTO AspNetUsersExt (UserId, SecurityQuestion, SecurityAnswer, SecurityAnswerSalt)
  SELECT aspnet_Users.UserId, aspnet_Membership.PasswordQuestion, PasswordAnswer, PasswordSalt
  FROM aspnet_Users
  LEFT OUTER JOIN aspnet_Membership ON aspnet_Membership.ApplicationId = aspnet_Users.ApplicationId 
  AND aspnet_Users.UserId = aspnet_Membership.UserId
  LEFT OUTER JOIN AspNetUsersExt ON aspnet_Membership.UserId = AspNetUsersExt.UserId
  LEFT OUTER JOIN AspNetUsers ON aspnet_Membership.UserId = AspNetUsers.Id
  WHERE AspNetUsers.Id IS NOT NULL AND AspNetUsersExt.UserId IS NULL

IF @@ERROR <> 0 
  BEGIN 
    ROLLBACK TRANSACTION MigrateUsers
    RETURN
  END

COMMIT TRANSACTION MigrateUsers



/*ALTER VIEW VW_SYSTEM_USER*/
DROP VIEW [dbo].[VW_SYSTEM_USER]
GO

CREATE VIEW [dbo].[VW_SYSTEM_USER]
AS
SELECT        dbo.AspNetUsers.UserName AS USERNAME, dbo.AspNetUsers.Email AS EMAIL, dbo.BASICMGR_ENTITY_BASIC_DATA.ENTITY_ID AS ENTITY_ID, dbo.BASICMGR_ENTITY_BASIC_DATA.FIRST_NAME,
                          dbo.BASICMGR_ENTITY_BASIC_DATA.LAST_NAME, dbo.BASICMGR_ENTITY_BASIC_DATA.TITLE, dbo.BASICMGR_ENTITY_BASIC_DATA.OTHER_NAME,
                         dbo.BASICMGR_ENTITY.BRANCH_ID, dbo.BASICMGR_BRANCH.NAME AS BRANCH_NAME, BASICMGR_ENTITY.STATUSID AS STATUS
FROM            dbo.BASICMGR_ENTITY_RELATIONSHIP INNER JOIN
                         dbo.BASICMGR_ENTITY ON dbo.BASICMGR_ENTITY_RELATIONSHIP.ENTITY_ID_TO = dbo.BASICMGR_ENTITY.ENTITY_ID AND dbo.BASICMGR_ENTITY_RELATIONSHIP.RELATION_FROM = 'SYSTEM_USER' INNER JOIN
                         dbo.AspNetUsers ON dbo.BASICMGR_ENTITY_RELATIONSHIP.ENTITY_ID_FROM = CONVERT(nvarchar(50), dbo.AspNetUsers.Id) INNER JOIN
                         dbo.BASICMGR_ENTITY_BASIC_DATA ON dbo.BASICMGR_ENTITY.ENTITY_ID = dbo.BASICMGR_ENTITY_BASIC_DATA.ENTITY_ID LEFT OUTER JOIN
                         dbo.BASICMGR_BRANCH ON dbo.BASICMGR_ENTITY.BRANCH_ID = dbo.BASICMGR_BRANCH.ID

GO


UPDATE AspNetUsers
SET EmailConfirmed = 0,
TwoFactorEnabled = 0, 
PasswordHash = 'AMJMYeJ7W+4BODiLpuQj/45wruNvOdIGQE1rQYRdKw4RLHzFdZQfkH8RmeJPLXZZzg==',
UserName = 'admin@database.co.mz'
WHERE Email = 'admin@database.co.mz'
GO

UPDATE AspNetUsers 
SET Email = 'augusto.eduardo@database.co.mz'
WHERE  UserName= 'augusto.eduardo@database.co.mz'
GO

UPDATE AspNetUsers
SET EmailConfirmed = 0,
TwoFactorEnabled = 0
WHERE Email = 'uzna.hassane@database.co.mz'
GO

/*Associando o user ao Branch*/
INSERT INTO BASICMGR_ENTITY_USER_BRANCH
VALUES('US0010', 3,1)
GO

ALTER VIEW [dbo].[VW_SYSTEM_USER]
AS
SELECT        dbo.AspNetUsers.UserName AS USERNAME, dbo.AspNetUsers.Email AS EMAIL,  dbo.AspNetUsers.PhoneNumber AS PHONENUMBER,  dbo.BASICMGR_ENTITY_BASIC_DATA.ENTITY_ID AS ENTITY_ID, dbo.BASICMGR_ENTITY_BASIC_DATA.FIRST_NAME,
                          dbo.BASICMGR_ENTITY_BASIC_DATA.LAST_NAME, dbo.BASICMGR_ENTITY_BASIC_DATA.TITLE, dbo.BASICMGR_ENTITY_BASIC_DATA.OTHER_NAME,
                         dbo.BASICMGR_ENTITY.BRANCH_ID, dbo.BASICMGR_BRANCH.NAME AS BRANCH_NAME, BASICMGR_ENTITY.STATUSID AS STATUS
FROM            dbo.BASICMGR_ENTITY_RELATIONSHIP INNER JOIN
                         dbo.BASICMGR_ENTITY ON dbo.BASICMGR_ENTITY_RELATIONSHIP.ENTITY_ID_TO = dbo.BASICMGR_ENTITY.ENTITY_ID AND dbo.BASICMGR_ENTITY_RELATIONSHIP.RELATION_FROM = 'SYSTEM_USER' INNER JOIN
                         dbo.AspNetUsers ON dbo.BASICMGR_ENTITY_RELATIONSHIP.ENTITY_ID_FROM = CONVERT(nvarchar(50), dbo.AspNetUsers.Id) INNER JOIN
                         dbo.BASICMGR_ENTITY_BASIC_DATA ON dbo.BASICMGR_ENTITY.ENTITY_ID = dbo.BASICMGR_ENTITY_BASIC_DATA.ENTITY_ID LEFT OUTER JOIN
                         dbo.BASICMGR_BRANCH ON dbo.BASICMGR_ENTITY.BRANCH_ID = dbo.BASICMGR_BRANCH.ID

GO
/*
END
Tulio Benedito
12/04/2022
*/