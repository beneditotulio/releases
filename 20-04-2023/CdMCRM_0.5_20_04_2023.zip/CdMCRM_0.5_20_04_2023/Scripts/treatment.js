﻿$(document).ready(function () {

    // ARRIVALS
    var table = $('#receiveTable').DataTable({
        paginate: true,
        autoWidth: false,
        select: true,
        //Necessario desativar o scrollX e scrollY para acertar o header com o body.
        //scrollResize: true,
        //scrollY: 300
        "pagingType": "full_numbers",
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Procurar ..."
        }
    });

    $('#receiveTable tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
            document.getElementById('verify').style.display = 'none';
            document.getElementById('receive').style.display = 'block';
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            var rState = $.map(table.rows('.selected').data(), function (item) {
                return item[8]
            });
            alert('b');
            if (rState == 'RECEIVED') {
                document.getElementById('verify').style.display = 'block';
                document.getElementById('receive').style.display = 'none';
            }
            else {
                document.getElementById('verify').style.display = 'none';
                document.getElementById('receive').style.display = 'block';
            }
        }
    });
    // OUTPUT / EXITS
    var table = $('#manageTable').DataTable({
        paginate: true,
        autoWidth: false,
        select: true,
        //Necessario desativar o scrollX e scrollY para acertar o header com o body.
        //scrollResize: true,
        //scrollY: 300
        "pagingType": "full_numbers",
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Procurar ..."
        }
    });

    $('#manageTable tbody').on('click', 'tr', function () {
        if ($(this).hasClass('selected')) {
            $(this).removeClass('selected');
            document.getElementById('verify').style.display = 'none';
            document.getElementById('receive').style.display = 'block';
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            var rState = $.map(table.rows('.selected').data(), function (item) {
                return item[8]
            });
            alert('a');
            if (rState == 'RECEIVED') {
                document.getElementById('verify').style.display = 'block';
                document.getElementById('receive').style.display = 'none';
            }
            else {
                document.getElementById('verify').style.display = 'none';
                document.getElementById('receive').style.display = 'block';
            }
        }
    });

});

function onVerify() {
    $("#receiving").modal();
}

function showMessage() {
    $('#msg').modal();
}

function onCreate() {
    $("#createBag").modal();
}
function onEdit() {
    $("#editBag").modal();
}

// REUSE OF THE METHOD: t => table id
function GetTableId(t) {
    var table = $('#'+t+'').DataTable();

    $('#'+t+' tbody').on('click', 'tr', function () {
        $(this).toggleClass('selected');
    });

    var code = $.map(table.rows('.selected').data(), function (item) {
        return item[0]
    });

    if (code == null || code == '') {
        alert("Atenção: Selecione uma mala na lista!");
        location.reload();
        code = 0;
    }
    return code;
}
// PASS AN ID TO AJAX ACTION LINK
var row = "rowId";
function addParameter(e, table) {
    var rowId = GetTableId(table);
    if (rowId != '') {
        e.href = e.href.replace(row, rowId[0]);
        row = id;
    }
}