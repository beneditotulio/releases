﻿

var init = "start", end = "ending";
function filter(e) {
    var ini = document.getElementById('init').value;
    var en = document.getElementById('end').value;

    e.href = e.href.replace(init, ini);
    e.href = e.href.replace(end, en);
    init = ini;
    end = en;

}